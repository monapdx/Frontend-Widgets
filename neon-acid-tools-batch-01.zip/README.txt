NEON ACID — BATCH 01

Open index.html to browse all 13 tools. Each tool embeds the complete shared theme and works without external CSS or fonts. Original filenames, script logic, element IDs, and local-storage keys are preserved.

neon-acid.css is the reusable theme for future batches. In these standalone files, specialized original geometry lives in the legacy CSS layer; the new theme owns shared presentation. To use a linked theme instead, replace style#neon-acid-theme with a link to neon-acid.css.

Responsive: two main columns above 1000px, stacked below; form rows stack at 600px. Includes keyboard focus styles, dark native controls, 44px minimum control heights, and reduced-motion support.

Generated content and export formats retain their original behavior. Browser clipboard/download permissions still apply.
